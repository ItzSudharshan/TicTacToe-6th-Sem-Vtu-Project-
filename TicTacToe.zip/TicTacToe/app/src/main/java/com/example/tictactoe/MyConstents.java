package com.example.tictactoe;

public class MyConstents {
    public static String playerName = "";
}
